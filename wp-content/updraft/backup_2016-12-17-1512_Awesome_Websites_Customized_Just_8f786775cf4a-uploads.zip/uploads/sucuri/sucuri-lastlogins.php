<?php exit(0); ?>
{"user_id":1,"user_login":"bootstrap_admin","user_remoteaddr":"127.0.0.1","user_hostname":"localhost","user_lastlogin":"2016-12-01 19:43:45"}
{"user_id":1,"user_login":"bootstrap_admin","user_remoteaddr":"127.0.0.1","user_hostname":"localhost","user_lastlogin":"2016-12-17 15:12:39"}
