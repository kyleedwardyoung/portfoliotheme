<?php

$instructor_section_title_2 = get_field('instructor_section_title_2');

$instructor_name_2     = get_field('instructor_name_2');

$bio_excerpt_2         = get_field('bio_excerpt_2');

$full_bio_2            = get_field('full_bio_2');

$linked_in_username_2   = get_field('linked_in_username_2');

$twitter_username_2    = get_field('twitter_username_2');

$facebook_username_2   = get_field('facebook_username_2');

$google_plus_username_2 = get_field('google_plus_username_2');

$number_of_students_2  = get_field('number_of_students_2');

$number_of_reviews_2   = get_field('number_of_reviews_2');

$number_of_courses_2   = get_field('number_of_courses_2');





?>
           

           
           
<!-- INSTRUCTOR============================================== -->
        	<section id="instructor">
		<div class="container">
			<div class="row">
				<div class="col-sm-8 col-md-6">
					<div class="row">
						<div class="col-lg-8">
							<h2><?php echo $instructor_section_title_2; ?> <small><?php echo $instructor_name_2; ?></small></h2>
						</div><!-- end col -->
						
						
						<div class="col-lg-5">
						
						
						<?php if( !empty($linked_in_username_2) ) : ?>
							<a href="https://www.linkedin.com/in/<?php echo $linked_in_username_2; ?>" class="badge social gplus" target="_blank"><i class="fa fa-linkedin"></i></a>
							<?php endif; ?>
							
							
						<?php if( !empty($twitter_username_2) ) : ?>
							<a href="https://twitter.com/<?php echo $twitter_username_2; ?>" class="badge social twitter" target="_blank"><i class="fa fa-twitter"></i></a>
							<?php endif; ?>
							
							
							<?php if( !empty($facebook_username_2) ) : ?>
							<a href="https://facebook.com/<?php echo $facebook_username_2; ?>" class="badge social facebook" target="_blank"><i class="fa fa-facebook"></i></a>
							<?php endif; ?>
							
							<?php if( !empty($google_plus_username_2) ) : ?>
							<a href="https://plus.google.com/u/0/<?php echo $google_plus_username_2; ?>" class="badge social gplus" target="_blank"><i class="fa fa-google-plus"></i></a>
							<?php endif; ?>
							
							
						</div><!-- end col -->
					
					</div><!-- row -->
					
					<p class="lead"><?php echo $bio_excerpt_2; ?><p>
					
					<?php echo $full_bio_2; ?>
					
					<hr>
					
					<h3>The Numbers <small>They Don't Lie</small></h3>
					<div class="row">
						<div class="col-xs-4">
							<div class="num">
								<div class="num-content">
									<?php echo $number_of_students_2; ?> <span>Clients</span>
								</div><!-- num-content -->
							</div><!-- num -->
						</div><!-- end col -->
						
						<div class="col-xs-4">
							<div class="num">
								<div class="num-content">
									<?php echo $number_of_reviews_2; ?> <span>Reviews</span>
								</div><!-- num-content -->
							</div><!-- num -->
						</div><!-- end col -->
						
						<div class="col-xs-4">
							<div class="num">
								<div class="num-content">
									<?php echo $number_of_courses_2; ?> <span>Websites</span>
								</div><!-- num-content -->
							</div><!-- num -->
						</div><!-- end col -->
					</div><!-- row -->
					
				</div><!-- end col -->
			</div><!-- row -->
		</div><!-- container -->
	</section><!-- instructor -->