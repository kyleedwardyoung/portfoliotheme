<?php
/*
	Template Name: About Page	
*/




get_header(); ?>
    
    
    
    
    

	<? /*php get_template_part('content', 'hero');*/ ?>
        
	
       
    <?php get_template_part('content', 'instructor'); ?>
       
   
        
    
<?php get_footer(); ?>